﻿function ShowAlertandRedirect(url, title, msg, cssclass, timeout, ConfirmButtonColor, IsHTML) {
    swal({
        "title": title,
        "text": msg,
        "type": cssclass,
        "confirmButtonColor": ConfirmButtonColor,
        "timer": timeout,
        "html": IsHTML
    });

    //swal(title, msg, cssclass);

    if (url !== 'NA') {
        window.setTimeout(function () {
            window.location.href = url;
        }, parseInt(timeout));
    }
}

function ShowModalAlert() {
    var s = "#" + ModalID;
    $(s).modal('show');
}